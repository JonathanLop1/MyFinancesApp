// IngresoDao.kt
package com.example.myfinances.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface IngresoDao {
    @Query("SELECT SUM(cantidad) FROM Ingreso")
    suspend fun totalIngresos(): Double?

    @Query("SELECT * FROM Ingreso")
    suspend fun getAllIngresos(): List<Ingreso>

    @Insert
    suspend fun insertIngreso(ingreso: Ingreso)

    @Query("SELECT COUNT(*) FROM Ingreso")
    suspend fun countIngresos(): Int

    @Query("SELECT * FROM ingreso")
    suspend fun getAll(): List<Ingreso>
}
