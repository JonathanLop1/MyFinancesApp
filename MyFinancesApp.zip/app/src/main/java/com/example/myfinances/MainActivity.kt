package com.example.myfinances

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

// 👇 Importa tu DataStoreManager desde la carpeta data
import com.example.myfinances.data.DataStoreManager
import com.example.myfinances.data.dataStore


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyFinancesApp()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyFinancesApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val dataStore = remember { DataStoreManager(context) }

    val savedTransactions by dataStore.transactions.collectAsState(initial = emptySet())
    val transactions = remember { mutableStateListOf<String>() }

    // cargar datos al iniciar
    LaunchedEffect(savedTransactions) {
        transactions.clear()
        transactions.addAll(savedTransactions)
    }

    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(Color(0xFF1976D2), Color(0xFF42A5F5))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text("💰 My Finances", color = Color.White, style = MaterialTheme.typography.titleLarge)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // input título
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Título") },
                leadingIcon = {
                    Icon(Icons.Default.Description, contentDescription = null, tint = Color(0xFF1976D2))
                },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))

            // input cantidad
            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it },
                label = { Text("Cantidad") },
                leadingIcon = {
                    Icon(Icons.Default.AttachMoney, contentDescription = null, tint = Color(0xFF388E3C))
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))

            // botones
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(
                    onClick = {
                        if (title.isNotBlank() && amount.isNotBlank()) {
                            val newTransaction = "Ingreso: $title - $amount"
                            transactions.add(newTransaction)
                            scope.launch { dataStore.saveTransactions(transactions) }
                            title = ""
                            amount = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388E3C)),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.weight(1f).padding(end = 4.dp)
                ) {
                    Text("➕ Ingreso")
                }
                Button(
                    onClick = {
                        if (title.isNotBlank() && amount.isNotBlank()) {
                            val newTransaction = "Gasto: $title - $amount"
                            transactions.add(newTransaction)
                            scope.launch { dataStore.saveTransactions(transactions) }
                            title = ""
                            amount = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.weight(1f).padding(start = 4.dp)
                ) {
                    Text("➖ Gasto")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // tabla resumen
            SummaryTable(transactions)

            Spacer(modifier = Modifier.height(16.dp))

            // lista historial
            Text("📑 Historial", style = MaterialTheme.typography.titleMedium)
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                itemsIndexed(transactions) { index, item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (item.startsWith("Gasto")) Color(0xFFFFEBEE) else Color(0xFFE8F5E9)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(item, style = MaterialTheme.typography.bodyLarge)
                            IconButton(onClick = {
                                transactions.removeAt(index)
                                scope.launch { dataStore.saveTransactions(transactions) }
                            }) {
                                Icon(
                                    imageVector = Icons.Filled.Delete,
                                    contentDescription = "Eliminar",
                                    tint = Color.Red
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SummaryTable(transactions: List<String>) {
    val gastos = transactions.filter { it.startsWith("Gasto") }
    val ingresos = transactions.filter { it.startsWith("Ingreso") }

    val totalGastos = gastos.sumOf {
        it.substringAfterLast(" ").toIntOrNull() ?: 0
    }
    val totalIngresos = ingresos.sumOf {
        it.substringAfterLast(" ").toIntOrNull() ?: 0
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text("📊 Resumen", style = MaterialTheme.typography.titleMedium, color = Color(0xFF1976D2))
            Spacer(modifier = Modifier.height(6.dp))
            Text("Cantidad de Gastos: ${gastos.size}")
            Text("Total de Gastos: $totalGastos")
            Text("Cantidad de Ingresos: ${ingresos.size}")
            Text("Total de Ingresos: $totalIngresos")
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            Text("💵 Balance: ${totalIngresos - totalGastos}", style = MaterialTheme.typography.bodyLarge, color = Color.Black)
        }
    }
}
