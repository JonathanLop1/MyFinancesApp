// GastoDao.kt
package com.example.myfinances.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface GastoDao {
    @Query("SELECT SUM(cantidad) FROM Gasto")
    suspend fun totalGastos(): Double?

    @Query("SELECT * FROM Gasto")
    suspend fun getAllGastos(): List<Gasto>

    @Insert
    suspend fun insertGasto(gasto: Gasto)

    @Query("SELECT COUNT(*) FROM Gasto")
    suspend fun countGastos(): Int

    @Query("SELECT * FROM gasto")
    suspend fun getAll(): List<Gasto>
}